<?php
include 'db_config.php';

header('Content-Type: application/json');


ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$pdo = new PDO("mysql:host=$db_host;dbname=$db_name", $db_user, $db_pass);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


if (isset($_GET['cache_types'])) {
    $stmt = $pdo->query("SELECT type_id, cache_type FROM cache_types");
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    exit;
}


$type = $_GET['type'] ?? '';
$difficulty = $_GET['difficulty'] ?? '';
$distance = $_GET['distance'] ?? 10;


$baseLat = 32.253;
$baseLng = -110.912;
$latDiff = $distance / 69.0;
$lngDiff = $distance / (cos(deg2rad($baseLat)) * 69.0);

$minLat = $baseLat - $latDiff;
$maxLat = $baseLat + $latDiff;
$minLng = $baseLng - $lngDiff;
$maxLng = $baseLng + $lngDiff;


$query = "SELECT td.cache_id, td.latitude, td.longitude, td.difficulty_rating AS difficulty, ct.cache_type AS type
          FROM test_data td
          JOIN cache_types ct ON td.cache_type_id = ct.type_id
          WHERE td.latitude BETWEEN :minLat AND :maxLat
            AND td.longitude BETWEEN :minLng AND :maxLng";

$params = [
    ':minLat' => $minLat,
    ':maxLat' => $maxLat,
    ':minLng' => $minLng,
    ':maxLng' => $maxLng
];

if ($type !== '') {
    $query .= " AND td.cache_type_id = :type";
    $params[':type'] = $type;
}
if ($difficulty !== '') {
    $query .= " AND td.difficulty_rating = :difficulty";
    $params[':difficulty'] = $difficulty;
}

$stmt = $pdo->prepare($query);
$stmt->execute($params);
echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));


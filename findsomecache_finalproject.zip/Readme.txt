FindSomeCache - Final Project (CSCV337)
=======================================

Author: Korey Dillon  
Course: CSCV337 - Web Programming  
Instructor: Professor Vieri

Project Summary:
----------------
This is a web-based geocache search application that allows users to:
- View geocache locations on a Google Map
- Filter by cache type, difficulty rating, and distance from Tucson
- View results in a table and on the map simultaneously
- Click on a result to see nearby Flickr photo thumbnails

How to Run the App Locally:
---------------------------
1. Install XAMPP (https://www.apachefriends.org)
2. Start Apache and MySQL from the XAMPP Control Panel

3. Place the unzipped project folder `findsomecache/` in:
   C:\xampp\htdocs\findsomecache

4. Import the database:
   - Open http://localhost/phpmyadmin
   - Create a database named: `test`
   - Import both `test_data.csv` and `cache_types.csv` into the `test` database using the Import tab
   - Ensure column names match your CSV headers

5. Visit the app in your browser:
   http://localhost/findsomecache/

6. Use the dropdowns to filter by cache type, difficulty, and distance.
   - Results will appear in the table and on the map.
   - Click a marker or row to view Flickr photos nearby.

API Keys Used:
--------------
Google Maps JavaScript API:
- Key: ✅ Already embedded

Flickr API:
- Using a publicly available test key for demonstration purposes:
  `3cfb5b45ac2809a2eaa28e18b8f43205`

Credits:
--------
- Google Maps API
- Flickr Photo API
- University of Arizona instructional materials

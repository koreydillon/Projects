<?php
$db_host = 'localhost';
$db_name = 'test';
$db_user = 'root';
$db_pass = '';

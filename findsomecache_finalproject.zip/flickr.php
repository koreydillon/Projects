<?php
header('Content-Type: application/json');

$lat = $_GET['lat'] ?? '32.253';
$lon = $_GET['lon'] ?? '-110.912';
$api_key = '3cfb5b45ac2809a2eaa28e18b8f43205';


$url = "https://www.flickr.com/services/rest/?method=flickr.photos.search&api_key=$api_key&lat=$lat&lon=$lon&radius=5&format=json&nojsoncallback=1&per_page=12";


$response = file_get_contents($url);
$data = json_decode($response, true);
$photos = $data['photos']['photo'] ?? [];

$thumbnails = [];
foreach ($photos as $photo) {
    $thumb = "https://farm{$photo['farm']}.staticflickr.com/{$photo['server']}/{$photo['id']}_{$photo['secret']}_t.jpg";
    $thumbnails[] = $thumb;
}

echo json_encode($thumbnails);

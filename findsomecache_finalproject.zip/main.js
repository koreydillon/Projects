
let map;
let markers = [];

function initMap() {
    const centerPos = { lat: 32.253, lng: -110.912 };
    map = new google.maps.Map(document.getElementById("map"), {
        center: centerPos,
        zoom: 8
    });
}

window.onload = () => {
    initMap();
    fetch("data.php?cache_types=1")
        .then(res => res.json())
        .then(data => {
            const cacheTypeSelect = document.getElementById("cacheType");
            data.forEach(type => {
                const option = document.createElement("option");
                option.value = type.type_id;
                option.textContent = type.cache_type;

                cacheTypeSelect.appendChild(option);
            });
        });
};

function loadGeocaches() {
    const type = document.getElementById("cacheType").value;
    const difficulty = document.getElementById("difficulty").value;
    const distance = document.getElementById("distance").value || 10;

    fetch(`data.php?type=${type}&difficulty=${difficulty}&distance=${distance}`)
        .then(res => res.json())
        .then(data => {
            markers.forEach(marker => marker.setMap(null));
            markers = [];
            const table = document.getElementById("resultsTable");
            table.innerHTML = "<tr><th>Name</th><th>Type</th><th>Difficulty</th></tr>";
            data.forEach(entry => {
                const row = table.insertRow();
                row.innerHTML = `<td>Cache #${entry.cache_id}</td><td>${entry.type}</td><td>${entry.difficulty}</td>`;
                row.onclick = () => showPhotos(entry.latitude, entry.longitude);

                const marker = new google.maps.Marker({
                    position: { lat: parseFloat(entry.latitude), lng: parseFloat(entry.longitude) },
                    map,
                    title: `Cache #${entry.cache_id}`

                });
                marker.addListener("click", () => showPhotos(entry.latitude, entry.longitude));
                markers.push(marker);
            });
        });
}

function showPhotos(lat, lng) {
    fetch(`flickr.php?lat=${lat}&lon=${lng}`)
        .then(res => res.json())
        .then(data => {
            const container = document.getElementById("photoThumbnails");
            container.innerHTML = data.map(url => `<img src="\${url}" style="width:75px; margin:3px">`).join("");
        });
}
